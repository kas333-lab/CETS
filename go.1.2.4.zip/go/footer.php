<?php
/**
 * The template for displaying the footer.
 *
 * @package Go
 */

?>

	</main>

	<?php Go\footer_variation(); ?>

	</div>

	<?php wp_footer(); ?>

	</body>
</html>
